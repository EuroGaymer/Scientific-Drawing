"""
This is a module which takes Dataframe as imput and output the graphs for\
 academic(fake) purpose~**

"""
